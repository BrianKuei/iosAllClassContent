//
//  ViewController.swift
//  DownloadImage
//
//  Created by Sunbu on 2019/5/9.
//  Copyright © 2019 Sunbu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let docPath = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)

        print(docPath)
        
        if docPath.count > 0 {
            let savePath = docPath[0] + "/cuteCat.jpg"
            imageView.image = UIImage(contentsOfFile: savePath)
            imageView.contentMode = .scaleAspectFill
        }
        
//        let myUrl = URL(string: "https://images.unsplash.com/photo-1415369629372-26f2fe60c467?ixlib=rb-1.2.1&auto=format&fit=crop&w=668&q=80")
//
//        let request = URLRequest(url: myUrl!)
//
//        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
//            if error != nil {
//                print(error)
//            }else {
//                if let imgData = data {
//                    DispatchQueue.main.async {
//                        self.imageView.image = UIImage(data: imgData)
//                        self.imageView.contentMode = .scaleAspectFit
//                    }
//
//
//
//                    let docPath = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
//                    print(docPath[0])
//
//                    if docPath.count > 0 {
//                        let savePath = docPath[0] + "/cuteCat.jpg"
//                        let image = UIImage(data: imgData)
//
//                        do{
//                            try image?.jpegData(compressionQuality: 0.8)?.write(to: URL(fileURLWithPath: savePath))
//                            print("save successfully")
//                        } catch {
//                            print("save failed")
//                        }
//
//                    }
//                }
//            }
//        }
//        task.resume()
    }


}

