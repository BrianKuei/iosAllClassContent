//
//  main.swift
//  Class
//
//  Created by student on 2019/3/14.
//  Copyright © 2019年 student. All rights reserved.
//

import Foundation

var myCar = Car(customeColor: "blue")
print(myCar.numOfSeat)
myCar.printOut()
print(myCar.color)

var eCar = ElectricCar(customeColor: "silver")
print(eCar.source)
print(eCar.numOfSeat)
eCar.printOut()
