//
//  ViewController.swift
//  LoginScreen
//
//  Created by student on 2019/4/25.
//  Copyright © 2019年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        let bgImageView = UIImageView()
//        
//        bgImageView.image = UIImage(named: "bgimage")
//        bgImageView.frame = CGRect(x: 0, y: 0, width: (bgImageView.image?.size.width)!, height: view.frame.height)
//        
//        view.addSubview(bgImageView)
//        
//        view.sendSubviewToBack(bgImageView)
    }


}

