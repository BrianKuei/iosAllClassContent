//
//  ViewController.swift
//  multipleView
//
//  Created by student on 2019/3/21.
//  Copyright © 2019年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func button(_ sender: UIButton) {
        performSegue(withIdentifier: "gotoSec", sender: self)
    }
    @IBOutlet weak var textField: UITextField!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "gotoSec"{
            let destViewController = segue.destination as! SecViewController
            
            destViewController.tempText = textField.text
        }
        
    }
    
}

