//
//  ViewController.swift
//  tempSave
//
//  Created by student on 2019/3/28.
//  Copyright © 2019年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let myArray = ["Eva",2019,true] as Any
    
    //let name = "Jeff"

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        UserDefaults.standard.set("jeff", forKey: "name")
        let nameObj = UserDefaults.standard.object(forKey: "name")
        //as! 我確定會是改用STRING，用!強迫轉型。?是可以存陳列
        if let nameString = nameObj as? String{
            print(nameString)
        }
        
        //print(nameObj)
        
        UserDefaults.standard.set(myArray, forKey: "info")
        let nameObjA = UserDefaults.standard.object(forKey: "info")
        if let infoA = nameObjA as? NSArray{
            print(infoA)
        }
        
    }


}

