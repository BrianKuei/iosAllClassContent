import UIKit
import CoreData

class SecondViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var userArr : [Username] = []
    @IBOutlet weak var tableView: UITableView!
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let person = userArr[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = person.value(forKeyPath: "userID") as? String
        return cell!
    }
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        fetch()
    }
    
    func fetch(){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let myContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<Username>(entityName: "Username")
        fetchRequest.returnsObjectsAsFaults = false
        
        do {
            userArr = try myContext.fetch(fetchRequest)
            if userArr.count > 0 {
                for user in userArr {
                    print(user.userID ?? "I'm Jeff")
                }
            }
            
        }catch {
            print("fetch failed")
        }
    }
    
    func deleteItem(index: IndexPath){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let myContext = appDelegate.persistentContainer.viewContext
        
        myContext.delete(userArr[index.row])
        
        do{
            try myContext.save()
        }catch{
            print("data deletion failed.")
        }
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let deleteAction = UITableViewRowAction(style: UITableViewRowAction.Style.default, title: "Deletion") { (rowaction, indexPath) in
            self.deleteItem(index: indexPath)
            self.fetch()
            self.tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.fade)
            
        }
        deleteAction.backgroundColor = UIColor.red
        
        return [deleteAction]
    }
}

