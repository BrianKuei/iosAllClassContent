//
//  ViewController.swift
//  manualAdj
//
//  Created by student on 2019/3/28.
//  Copyright © 2019年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        let square = UIView(frame: CGRect.init(x: view.frame.width/2  , y: view.frame.height/2, width: 100, height: 100))
//        square.backgroundColor = UIColor.orange
//        
//        view.addSubview(square)
    }


}

