//
//  ViewController.swift
//  CoverShow
//
//  Created by Yi-Chin Huang on 2019/4/24.
//  Copyright © 2019 Yi-Chin Huang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //先做連接
    @IBOutlet weak var titalLab: UILabel!
    
    @IBOutlet weak var subtitleLab: UILabel!
    
    @IBOutlet weak var iconImage: UIImageView!
    
    @IBOutlet weak var orderLab: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //先做隱藏
        //在屬性面板設定alpha為0
        titalLab.alpha = 0
        subtitleLab.alpha = 0
        iconImage.alpha = 0
        orderLab.alpha = 0
        
        //再來設高度 先拉下去一點點 再往上移動
        titalLab.center.y += 30
        subtitleLab.center.y += 30
        iconImage.center.y += 30
        orderLab.center.y += 30
        
        //此時執行程式會發現沒有東西 因為已經隱藏了
        //接下來用viewdidappear
        
    }
    
    

    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 1, animations: {

//            //調整alpha 根位置
            self.moveUP(label: self.titalLab)

        }) { (finished) in
            UIView.animate(withDuration: 1, animations: {
                self.moveUP(label: self.subtitleLab)
            }, completion: { (finished) in
                UIView.animate(withDuration: 1, animations: {
                    self.moveUp(image: self.iconImage)
                }, completion: { (finished) in
                    UIView.animate(withDuration: 1, animations: {
                        self.moveUP(label: self.orderLab)
                        //最後可以請同學
                    })
                })
            })
        }
        
        
    }

    
    func moveUP(label: UILabel){
        label.alpha = 1
        label.center.y -= 30
    }
    
    func moveUp(image: UIImageView){
        image.alpha = 1
        image.center.y -= 30
    }
}

